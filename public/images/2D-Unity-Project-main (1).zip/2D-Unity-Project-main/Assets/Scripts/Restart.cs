using UnityEngine;

public class Restart : MonoBehaviour
{
    public void LoadCurrentScene()
    {
        UnityEngine.SceneManagement.SceneManager.LoadScene("GamesSences");
        Time.timeScale = 1;

    }
}
